/* Contact form: no backend yet. Builds a mailto: link and opens the visitor's email app.
   It never claims the message was sent. */
(function () {
  'use strict';
  var form = document.querySelector('[data-contact-form]');
  if (!form) return;
  var status = form.querySelector('[data-form-status]');
  var site = window.SITE || {};
  var to = site.email || '';

  function setError(input, msg) {
    var err = document.getElementById(input.id + '-err');
    if (msg) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid');
    if (err) err.textContent = msg || '';
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = form.elements.name, venue = form.elements.venue, contact = form.elements.contact, message = form.elements.message;
    var first = null;
    [[name, 'Please tell us your name.'], [contact, 'Please add a phone number or email address so we can reply.'], [message, 'Please write a short message.']].forEach(function (pair) {
      var ok = pair[0].value.trim().length > 0;
      setError(pair[0], ok ? '' : pair[1]);
      if (!ok && !first) first = pair[0];
    });
    if (first) { first.focus(); status.textContent = ''; return; }

    var subject = 'Enquiry about ' + (site.name || 'TableCall') + (venue.value.trim() ? ' from ' + venue.value.trim() : '');
    var body = [
      'Name: ' + name.value.trim(),
      'Venue: ' + (venue.value.trim() || '(not given)'),
      'Reply to: ' + contact.value.trim(),
      '',
      message.value.trim(),
    ].join('\r\n');
    var href = 'mailto:' + to + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);

    status.innerHTML = '';
    var p = document.createElement('p');
    p.textContent = 'Your email app should now open with your message ready. Press send there to reach us. If nothing opened, email us at ' + to + ' or use the link below.';
    var a = document.createElement('a');
    a.href = href; a.className = 'text-link'; a.textContent = 'Open the email again';
    var wrap = document.createElement('p'); wrap.style.marginTop = '8px'; wrap.appendChild(a);
    status.appendChild(p); status.appendChild(wrap);
    window.location.href = href;
  });

  ['name', 'contact', 'message'].forEach(function (n) {
    var el = form.elements[n];
    el.addEventListener('input', function () { if (el.getAttribute('aria-invalid') && el.value.trim()) setError(el, ''); });
  });
})();
