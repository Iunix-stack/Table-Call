/* Shared on every page: the mobile menu and gentle reveal-on-enter. */
(function () {
  'use strict';
  var html = document.documentElement;

  /* ---------- Mobile menu ---------- */
  var toggle = document.querySelector('[data-menu-toggle]');
  var menu = document.querySelector('[data-menu]');
  var backdrop = document.querySelector('[data-menu-backdrop]');
  var mq = window.matchMedia('(max-width: 899.98px)');

  function focusables() {
    return Array.prototype.slice.call(menu.querySelectorAll('a[href], button:not([disabled])'));
  }
  var lockedY = 0;
  function openMenu() {
    menu.classList.add('is-open');
    backdrop.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
    toggle.setAttribute('aria-label', 'Close menu');
    lockedY = window.scrollY;
    html.classList.add('menu-open');
    /* Some browsers jump when the page is locked: put it back where it was */
    if (window.scrollY !== lockedY) window.scrollTo(0, lockedY);
    var first = menu.querySelector('[aria-current="page"]') || focusables()[0];
    if (first) first.focus({ preventScroll: true });
  }
  function closeMenu(returnFocus) {
    if (!menu.classList.contains('is-open')) return;
    menu.classList.remove('is-open');
    backdrop.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Open menu');
    html.classList.remove('menu-open');
    if (window.scrollY !== lockedY) window.scrollTo(0, lockedY);
    if (returnFocus !== false) toggle.focus({ preventScroll: true });
  }
  if (toggle && menu && backdrop) {
    toggle.addEventListener('click', function () {
      if (menu.classList.contains('is-open')) closeMenu(); else openMenu();
    });
    backdrop.addEventListener('click', function () { closeMenu(); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) closeMenu(false); });
    document.addEventListener('click', function (e) {
      if (!menu.classList.contains('is-open')) return;
      if (!menu.contains(e.target) && !toggle.contains(e.target)) closeMenu();
    });
    document.addEventListener('keydown', function (e) {
      if (!menu.classList.contains('is-open')) return;
      if (e.key === 'Escape') { e.preventDefault(); closeMenu(); return; }
      if (e.key === 'Tab') {
        /* Keep focus inside the open menu (the toggle counts as part of it). */
        var items = [toggle].concat(focusables());
        var i = items.indexOf(document.activeElement);
        if (e.shiftKey && i <= 0) { e.preventDefault(); items[items.length - 1].focus(); }
        else if (!e.shiftKey && i === items.length - 1) { e.preventDefault(); items[0].focus(); }
      }
    });
    var onChange = function () { if (!mq.matches) closeMenu(false); };
    if (mq.addEventListener) mq.addEventListener('change', onChange); else mq.addListener(onChange);
  }

  /* ---------- Back to the beginning ----------
     On the Home page, the wordmark and the menu's Home link glide back to the top
     (the scenes play backwards on the way). Other pages navigate normally, with a
     soft cross-fade where the browser supports it (see @view-transition in base.css). */
  var onHome = document.body.classList.contains('page-home');
  if (onHome) {
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href="index.html"]');
      if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      closeMenu(false);
      var reduce = html.classList.contains('rm');
      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
      if (history.replaceState) history.replaceState(null, '', location.pathname);
      /* Hand focus to the top of the page once the glide has finished */
      var target = document.getElementById('main');
      if (target) {
        target.setAttribute('tabindex', '-1');
        var done = function () { target.focus({ preventScroll: true }); };
        if ('onscrollend' in window && !reduce) window.addEventListener('scrollend', done, { once: true });
        else setTimeout(done, reduce ? 0 : 900);
      }
    });
  }

  /* ---------- Reveal on enter (calm pages) ---------- */
  var items = document.querySelectorAll('[data-in]');
  if (items.length) {
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('is-in'); });
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
        });
      }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
      items.forEach(function (el) { io.observe(el); });
    }
  }
})();
