/* Scroll scenes for Home and How it works.
   Each [data-scene] gets --p (0..1) from scroll position. Scene hooks below
   drive page-specific state. Under reduced motion only the click demo runs. */
(function () {
  'use strict';
  var html = document.documentElement;
  var reduced = html.classList.contains('rm');
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var seg = function (p, a, b) { return clamp((p - a) / (b - a), 0, 1); };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- Hero unit: real buttons, works with or without motion ---------- */
  var heroUnit = $('[data-unit="hero"]');
  var unitTimer = 0;
  function setUnit(unit, state, text) {
    if (!unit) return;
    unit.setAttribute('data-state', state);
    var s = $('[data-unit-status]', unit);
    if (s && s.textContent !== text) s.textContent = text;
  }
  function pressUnit(kind) {
    clearTimeout(unitTimer);
    setUnit(heroUnit, 'calling', 'Calling your waiter');
    unitTimer = setTimeout(function () {
      if (kind === 'bill') setUnit(heroUnit, 'received-bill', 'Bill requested');
      else setUnit(heroUnit, 'received', 'Waiter called');
      unitTimer = setTimeout(function () { setUnit(heroUnit, 'ready', 'Tap to call'); }, 6000);
    }, reduced ? 300 : 1300);
  }
  if (heroUnit) {
    $$('[data-unit-press]', heroUnit).forEach(function (b) {
      b.addEventListener('click', function () { pressUnit(b.getAttribute('data-unit-press')); });
    });
  }

  /* Receipt in the close prints when it comes into view */
  var receipt = $('[data-receipt]');
  if (receipt && 'IntersectionObserver' in window && !reduced) {
    var rio = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { receipt.classList.add('is-in'); rio.disconnect(); } });
    }, { threshold: 0.3 });
    rio.observe(receipt.parentNode); /* the receipt itself is clipped to nothing until revealed */
  }

  if (reduced) return;

  /* ---------- Scene engine ---------- */
  var scenes = $$('[data-scene]').map(function (el) {
    return { el: el, name: el.getAttribute('data-scene'), enter: el.getAttribute('data-scene-mode') === 'enter', top: 0, h: 0, p: -1 };
  });
  var vh = window.innerHeight;
  var state = {};

  function measure() {
    vh = window.innerHeight;
    var y = window.scrollY;
    scenes.forEach(function (s) {
      var r = s.el.getBoundingClientRect();
      s.top = r.top + y; s.h = s.el.offsetHeight;
    });
    hooks.measure && hooks.measure();
  }

  var hooks = {};
  var ticking = false;
  function frame() {
    ticking = false;
    var y = window.scrollY;
    for (var i = 0; i < scenes.length; i++) {
      var s = scenes[i], p;
      if (s.enter) p = clamp((y + vh - s.top) / (vh * 0.9), 0, 1);
      else {
        var run = s.h - (vh - headerH());
        p = run > 0 ? clamp((y + headerH() - s.top) / run, 0, 1) : 0;
      }
      state[s.name] = p;
      if (Math.abs(p - s.p) > 0.0004) {
        s.p = p;
        s.el.style.setProperty('--p', p.toFixed(4));
        if (hooks[s.name]) hooks[s.name](s.el, p);
      }
    }
    if (hooks.after) hooks.after();
  }
  function headerH() { var h = $('[data-header]'); return h ? h.offsetHeight : 0; }
  function request() { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }

  /* ---------- HOME: hero ---------- */
  var heroZone = -1;
  hooks.hero = function (el, p) {
    var zone = p < 0.5 ? 0 : p < 0.66 ? 1 : 2;
    if (zone !== heroZone) {
      heroZone = zone;
      clearTimeout(unitTimer);
      if (zone === 0) setUnit(heroUnit, 'ready', 'Tap to call');
      else if (zone === 1) setUnit(heroUnit, 'calling', 'Calling your waiter');
      else setUnit(heroUnit, 'received', 'Waiter called');
      var svc = heroUnit && $('.unit__btn--service', heroUnit);
      if (svc) svc.classList.toggle('is-pressed', zone === 1);
    }
  };

  /* ---------- HOME: the call travels (lateral pan) ---------- */
  var track = $('[data-track]');
  var panDist = 0, panels = [];
  hooks.measure = function () {
    if (track) {
      track.style.setProperty('--x', 0);
      panDist = Math.max(0, track.scrollWidth - track.parentNode.clientWidth);
      panels = $$('.travel__panel', track);
    }
    if (howSteps.length) measureHow();
  };
  hooks.travel = function (el, p) {
    if (!track) return;
    var pp = seg(p, 0.04, 0.96);
    var x = pp * panDist;
    track.style.setProperty('--x', x.toFixed(1));
    var mid = track.parentNode.clientWidth / 2;
    panels.forEach(function (pn) {
      var c = pn.offsetLeft + pn.offsetWidth / 2 - x;
      var d = Math.abs(c - mid) / (track.parentNode.clientWidth * 0.6);
      pn.style.opacity = (1 - clamp(d * 1.3, 0, 1) * 0.85).toFixed(3);
    });
  };

  /* ---------- HOME: escalation (peak) ---------- */
  var timerEl = $('[data-timer]');
  var lastSec = -1;
  hooks.peak = function (el, p) {
    var flood = seg(p, 0.55, 0.72);
    var st = el.style;
    st.setProperty('--d', seg(p, 0, 0.12).toFixed(3));
    st.setProperty('--a1', (seg(p, 0.03, 0.1) * (1 - seg(p, 0.42, 0.5))).toFixed(3));
    st.setProperty('--a2', (seg(p, 0.13, 0.21) * (1 - seg(p, 0.5, 0.56))).toFixed(3));
    st.setProperty('--a3', seg(p, 0.19, 0.25).toFixed(3));
    st.setProperty('--g', (seg(p, 0.44, 0.55) * (1 - flood)).toFixed(3));
    st.setProperty('--f', flood.toFixed(4));
    st.setProperty('--r', seg(p, 0.66, 0.74).toFixed(3));
    if (timerEl) {
      var sec = Math.round(seg(p, 0.2, 0.55) * 220);
      if (sec !== lastSec) {
        lastSec = sec;
        timerEl.textContent = Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0');
      }
    }
  };

  /* ---------- HOME: report reveal ---------- */
  hooks.report = function (el, p) {
    el.style.setProperty('--bp', seg(p, 0.35, 0.95).toFixed(3));
  };

  /* ---------- HOME: running ticket (signature) ---------- */
  var ticket = $('[data-ticket]');
  var tLines = $('[data-ticket-lines]');
  var tClock = $('[data-ticket-clock]');
  var STAMPS = [
    { s: 'hero', at: 0.6, a: 'T14 Service', b: 'pressed', t: '0:00' },
    { s: 'travel', at: 0.3, a: '', b: 'received', t: '0:02' },
    { s: 'travel', at: 0.5, a: '', b: 'waiter alerted', t: '0:03' },
    { s: 'travel', at: 0.78, a: '', b: 'arrived', t: '1:10' },
    { s: 'peak', at: 0.1, a: 'T9 Bill', b: 'pressed', t: '0:00' },
    { s: 'peak', at: 0.36, a: '', b: 'no response', t: '…' },
    { s: 'peak', at: 0.6, a: '', b: 'manager alerted', t: '3:40', late: true },
  ];
  var shown = -1;
  hooks.after = function () {
    if (!ticket) return;
    var n = 0;
    for (var i = 0; i < STAMPS.length; i++) if ((state[STAMPS[i].s] || 0) >= STAMPS[i].at) n = i + 1;
    if (n !== shown) {
      shown = n;
      var out = '';
      for (var j = 0; j < n; j++) {
        var st = STAMPS[j];
        var label = st.a || (j >= 4 ? 'T9 Bill' : 'T14 Service');
        out += '<li' + (st.late ? ' class="is-late"' : '') + '><span>' + (st.a || '<span class="visually-hidden">' + label + '</span>') + '</span><span>' + st.b + '</span><b>' + st.t + '</b></li>';
      }
      tLines.innerHTML = out;
      if (n) tClock.textContent = STAMPS[n - 1].t;
    }
    if (state.peak > 0.2 && state.peak < 0.6 && timerEl) tClock.textContent = timerEl.textContent;
    var on = shown > 0 && (state.peak || 0) < 0.66;
    ticket.classList.toggle('is-on', on);
  };

  /* ---------- HOW IT WORKS: route that draws itself ---------- */
  var howSteps = $$('[data-how-step]');
  var howRoute = $('[data-how-route]');
  var howStations = $$('[data-station]');
  var howLen = 0, stepTops = [];
  function measureHow() {
    var y = window.scrollY;
    stepTops = howSteps.map(function (s) { var r = s.getBoundingClientRect(); return { top: r.top + y, h: r.height }; });
    if (howRoute && howRoute.getTotalLength) {
      howLen = howRoute.getTotalLength();
      howRoute.style.strokeDasharray = howLen;
    }
  }
  function howFrame() {
    if (!howSteps.length) return;
    var y = window.scrollY + vh * 0.5;
    var active = 0, prog = 0;
    for (var i = 0; i < stepTops.length; i++) {
      if (y >= stepTops[i].top) { active = i; prog = i + clamp((y - stepTops[i].top) / stepTops[i].h, 0, 1); }
    }
    if (y < stepTops[0].top) prog = 0;
    var frac = clamp(prog / howSteps.length, 0, 1);
    if (howRoute) howRoute.style.strokeDashoffset = (howLen * (1 - frac)).toFixed(1);
    howSteps.forEach(function (s, k) { s.classList.toggle('is-active', k === active && y >= stepTops[0].top); });
    howStations.forEach(function (st) {
      var k = +st.getAttribute('data-station');
      st.classList.toggle('is-done', prog >= k + 0.15);
      st.classList.toggle('is-active', k === active && y >= stepTops[0].top);
    });
    var bar = $('[data-how-progress]');
    if (bar) bar.style.setProperty('--hp', frac.toFixed(3));
  }
  if (howSteps.length) {
    var prevAfter = hooks.after;
    hooks.after = function () { if (prevAfter) prevAfter(); howFrame(); };
  }

  /* ---------- Wire up ---------- */
  measure();
  frame();
  window.addEventListener('scroll', request, { passive: true });
  window.addEventListener('resize', function () { measure(); scenes.forEach(function (s) { s.p = -1; }); request(); });
  window.addEventListener('load', function () { measure(); scenes.forEach(function (s) { s.p = -1; }); request(); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { measure(); request(); });
})();
