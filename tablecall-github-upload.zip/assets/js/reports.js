/* Reports page: a sample dashboard computed from made-up calls.
   Everything is generated here from a fixed seed, so it is the same on every visit. */
(function () {
  'use strict';
  var root = document.querySelector('[data-dash]');
  if (!root) return;

  /* Deterministic random numbers */
  function rng(seed) { return function () { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }; }

  var WAITERS = [
    { name: 'Sipho', speed: 40, tables: [1, 2, 3, 4] },
    { name: 'Thabo', speed: 50, tables: [5, 6, 7] },
    { name: 'Johan', speed: 58, tables: [8, 9, 10] },
    { name: 'Anika', speed: 66, tables: [11, 12, 13] },
    { name: 'Lerato', speed: 80, tables: [14, 15, 16] },
  ];
  var FAR = { 13: 22, 14: 26, 15: 30, 16: 18 }; /* sample: tables in a far corner */
  var ESCALATE_AFTER = 180;

  function makeCalls(nights, seed) {
    var r = rng(seed), calls = [];
    for (var n = 0; n < nights; n++) {
      var count = 46 + Math.floor(r() * 26);
      for (var i = 0; i < count; i++) {
        var w = WAITERS[Math.floor(r() * WAITERS.length)];
        var t = w.tables[Math.floor(r() * w.tables.length)];
        var secs = Math.round(w.speed * (0.55 + r() * 1.1) + (FAR[t] || 0) * r() + (r() < 0.04 ? 140 + r() * 120 : 0));
        calls.push({ waiter: w.name, table: t, kind: r() < 0.7 ? 'Service' : 'Bill', secs: secs, escalated: secs > ESCALATE_AFTER });
      }
    }
    return calls;
  }
  var DATA = { night: makeCalls(1, 20261121), week: makeCalls(7, 20261115) };

  var fmt = function (s) { s = Math.round(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  var avg = function (a) { return a.reduce(function (x, y) { return x + y; }, 0) / (a.length || 1); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  function render(period) {
    var calls = DATA[period];
    var all = calls.map(function (c) { return c.secs; });
    var escCount = calls.filter(function (c) { return c.escalated; }).length;

    var byW = WAITERS.map(function (w) {
      var mine = calls.filter(function (c) { return c.waiter === w.name; });
      var s = mine.map(function (c) { return c.secs; });
      return { name: w.name, n: mine.length, avg: avg(s), max: Math.max.apply(null, s.concat(0)), esc: mine.filter(function (c) { return c.escalated; }).length };
    }).sort(function (a, b) { return a.avg - b.avg; });
    var maxAvg = Math.max.apply(null, byW.map(function (w) { return w.avg; }));

    var byT = [];
    for (var t = 1; t <= 16; t++) {
      var tc = calls.filter(function (c) { return c.table === t; });
      byT.push({ t: t, n: tc.length, avg: avg(tc.map(function (c) { return c.secs; })) });
    }
    var tMin = Math.min.apply(null, byT.map(function (x) { return x.avg; }));
    var tMax = Math.max.apply(null, byT.map(function (x) { return x.avg; }));

    var label = period === 'night' ? 'tonight' : 'this week';
    var h = '';
    h += '<dl class="dash__summary">' +
      '<div><dt>Calls ' + label + '</dt><dd class="tnum">' + calls.length + '</dd></div>' +
      '<div><dt>Average response</dt><dd class="tnum">' + fmt(avg(all)) + '</dd></div>' +
      '<div><dt>Slowest response</dt><dd class="tnum">' + fmt(Math.max.apply(null, all)) + '</dd></div>' +
      '<div><dt>Escalated to a manager</dt><dd class="tnum">' + escCount + '</dd></div>' +
      '</dl>';

    h += '<div class="dash__cols"><div>';
    h += '<h2>Response time per waiter</h2><p class="dash__note">Press to arrival, fastest first.</p>';
    h += '<table class="dtable"><thead><tr><th scope="col">Waiter</th><th scope="col" class="num">Calls</th><th scope="col" class="num">Average</th><th scope="col" class="bar-cell hide-sm"><span class="visually-hidden">Average as a bar</span></th><th scope="col" class="num hide-sm">Slowest</th><th scope="col" class="num">Escalated</th></tr></thead><tbody>';
    byW.forEach(function (w, i) {
      h += '<tr' + (i === byW.length - 1 ? ' class="is-slow"' : '') + '><th scope="row">' + esc(w.name) + '</th><td class="num">' + w.n + '</td><td class="num">' + fmt(w.avg) +
        '</td><td class="bar-cell hide-sm" aria-hidden="true"><span class="bar" style="transform:scaleX(' + (w.avg / maxAvg).toFixed(3) + ')"></span></td><td class="num hide-sm">' + fmt(w.max) + '</td><td class="num">' + w.esc + '</td></tr>';
    });
    h += '</tbody></table></div>';

    h += '<div><h2>Average wait per table</h2><p class="dash__note">Darker means a longer wait.</p><ul class="heat" role="list">';
    byT.forEach(function (x) {
      var k = tMax > tMin ? (x.avg - tMin) / (tMax - tMin) : 0;
      h += '<li class="heat__cell" style="--h:' + (0.08 + k * 0.92).toFixed(2) + '"><span>Table ' + x.t + '</span><b class="tnum">' + fmt(x.avg) + '</b><span class="visually-hidden">, ' + x.n + ' calls</span></li>';
    });
    h += '</ul><p class="heat-key"><span>shorter</span><i aria-hidden="true"></i><span>longer</span></p></div></div>';

    root.innerHTML = h;
  }

  var buttons = document.querySelectorAll('[data-period]');
  buttons.forEach(function (b) {
    b.addEventListener('click', function () {
      buttons.forEach(function (o) { o.setAttribute('aria-pressed', String(o === b)); });
      render(b.getAttribute('data-period'));
    });
  });
  render('night');
})();
