/* Features page: the colour preview. Changes only the preview, nothing is saved. */
(function () {
  'use strict';
  var box = document.querySelector('[data-swatches]');
  var preview = document.querySelector('[data-colour-preview]');
  if (!box || !preview) return;
  box.addEventListener('change', function (e) {
    var v = e.target && e.target.value;
    if (v) preview.style.setProperty('--accent', v); else preview.style.removeProperty('--accent');
  });
})();
